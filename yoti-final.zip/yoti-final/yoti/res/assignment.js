window.onload = function(){ 
    document.getElementById("pdfButton").onclick = function() {
        window.open('/generatePdf');
    };
};